const express = require('express');
const app = express();
const port = 3008;

app.get('/', (req, res) => res.send('Hello World!'));

app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`));


const { Client, Intents, MessageReaction, GatewayIntentBits } = require("discord.js")
const allIntents = new Intents(32767);
const client = new Client({ intents: allIntents });
const { Collection } = require('discord.js');
const logChannelId = '1245317213003714641';
const roleId = '1230937127949172738';
const autoroleLog = '1243847776060837960';
const RemoveTimeoutL = '1245317213003714641';
const linkRegex = /https?:\/\/[^\s]+/;
const LinkLog = '1243847915555000351';
//const db = require('quick.db')
const { QuickDB } = require('quick.db');
const db = new QuickDB();
const Invites = new Collection();
const moment = require('moment');
const fs = require('fs');
const usersMap = new Map();
//const djs = require('djs-fun-v12')
const prefix = '!';
const { MessageActionRow, MessageSelectMenu, MessageButton, MessageEmbed } = require("discord.js")
const ms = require('ms')
const Discord = require('discord.js')
const axios = require('axios')
const { channel } = require('diagnostics_channel');
const { set } = require('express/lib/application');
const voiceCollection = new Collection();
const { AuditLogEvent } = require('discord.js');
const config = require('./config.json');
//let hastebin = require('hastebin');
const { syncBuiltinESMExports } = require("module");
const osu = require('node-os-utils');
var os = require('os');
const { ActionRowBuilder, Modal, TextInputBuilder, TextInputStyle, TextInputComponent } = require('discord.js');
client.commands = new Collection();
client.login(process.env.token)

////// Start Up \\\\\\
client.once('ready', () => {
  console.log(`${client.user.tag} is online`);
  //client.user.setActivity(config.game, { type: config.type });
  client.user.setPresence(
    {
      activities: [
        {
          name: config.game,
          type: config.type
        }
      ],
      status: "dnd" // online, idle, invisible, dnd
    }
  )
});




// Errors
client.on('shardError', error => {
  console.error('A websocket connection encountered an error:', error);
})

process.on('unhandledRejection', error => {
  console.error(error);
});

client.commands = new Collection();
const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.name, command);
}

client.on('messageCreate', message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'say') {
    client.commands.get('say').execute(message, args);
  }

  if (command === 'say2') {
    client.commands.get('say2').execute(message, args);
  }
});



//Giveaway
client.on('messageCreate', async message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;
  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'giveaway') {
    if (!message.member.permissions.has('ADMINISTRATOR')) return;

    let duration = args[0];
    let winnerCount = args[1];
    let duration_time = ms(args[0])

    if (!duration)
      return message.channel.send('**Give a valid duration** `d (ημέρες), h (ώρες), m (λεπτά), s (δευτερόλεπτα)`');
    if (
      !args[0].endsWith("d") &&
      !args[0].endsWith("h") &&
      !args[0].endsWith("m") &&
      !args[0].endsWith("s")
    )
      return message.channel.send("**Give a valid duration** `d (ημέρες), h (ώρες), m (λεπτά), s (δευτερόλεπτα)`");

    if (!winnerCount) return message.channel.send('Please provide the number of winners for the giveaway! E.g. `1w`')
    if (isNaN(args[1].toString().slice(0, -1)) || !args[1].endsWith("w")) return message.channel.send('Pleave provide the ammount of winners! example `1w`');
    if ((args[1].toString().slice(0, -1)) <= 0) return message.channel.send('The number of winners cannot be less than 1!');
    let giveawayChannel = message.mentions.channels.first();
    if (!giveawayChannel || !args[2]) return message.channel.send("**Please provide a channel to start the giveaway!**")
    let prize = args.slice(3).join(" ");
    if (!prize) return message.channel.send('**Please provide a prize!**');
    let startGiveawayEmbed = new MessageEmbed()
      .setAuthor({ name: message.channel.guild.name, iconURL: message.channel.guild.iconURL({ dynamic: true }) })
      .setThumbnail(message.channel.guild.iconURL({ dynamic: true }))
      .setDescription("```" + `${prize}` + "```\n" + " > ***Κάντε reaction στο 🎉 για να συμμετάσχετε στο giveaway!***\n\n" + `Το giveaway ληγει <t:${(Math.round((new Date()).getTime() / 1000) + parseInt(Math.floor(duration_time) / 1000))}:R>` + `\n**Hosted από τον/την:** <@${message.author.id}>\n` + `**Ποσό νικητών:**\`${winnerCount.toString().slice(0, -1)}\``)
      .setColor(config.color)
      .setTimestamp(Date.now() + duration_time)
      .setThumbnail(config.logo)
    giveawayChannel.send({ content: '@everyone', embeds: [startGiveawayEmbed] }).then(m => {
      m.react("🎉").catch(console.error);
      setTimeout(() => {
        if (m.reactions.cache.get("🎉").count <= 1) {
          const nooneGiveawayEmbed = new MessageEmbed()
            .setAuthor({ name: message.channel.guild.name, iconURL: message.channel.guild.iconURL({ dynamic: true }) })
            .setThumbnail(message.channel.guild.iconURL({ dynamic: true }))
            .setDescription("```" + `${prize}` + "```\n" + " > ***Κάντε reaction στο 🎉 για να συμμετάσχετε στο giveaway!***\n\n" + `**Πήραν μέρος:** \`${m.reactions.cache.get("🎉").count - 1}\`\n` + `**Hosted από τον/την:** <@${message.author.id}>\n` + `**Νικητής:** \`\`Κανείς\`\``)
            .setColor(config.color)
          m.edit({ embeds: [nooneGiveawayEmbed] })
          return giveawayChannel.send("**Δεν πήρε κανεις μερος**")
        }
        if (m.reactions.cache.get("🎉").count <= winnerCount.toString().slice(0, -1)) {
          return giveawayChannel.send("There's not enough people in the giveaway to satisfy the number of winners!")
        }
        let winner = m.reactions.cache.get("🎉").users.cache.filter((users) => !users.bot).random(winnerCount.toString().slice(0, -1));
        const endedEmbedGiveaway = new MessageEmbed()
          .setAuthor({ name: message.channel.guild.name, iconURL: message.channel.guild.iconURL({ dynamic: true }) })
          .setThumbnail(message.channel.guild.iconURL({ dynamic: true }))
          .setDescription("```" + `${prize}` + "```\n" + " > ***Κάντε reaction στο 🎉 για να συμμετάσχετε στο giveaway!***\n\n" + `**Πήραν μέρος:** \`${m.reactions.cache.get("🎉").count - 1}\`\n` + `**Hosted από τον/την:** <@${message.author.id}>\n` + `**Νικητής:** ${winner}`)
          .setColor(config.color)
          .setTimestamp(Date.now() + duration_time)
        const embed = new MessageEmbed()
          .setTitle("Giveaway Result")
          .setDescription(`**ο/οι νικητής/νικητές του Giveaway είναι: ${winner}**`)
          .setColor(config.color)
        const reroll = new MessageButton()
          .setEmoji("🔁")
          .setStyle("SECONDARY")
          .setLabel("Reroll")
          .setCustomId("reroll")
        const row = new MessageActionRow()
          .addComponents(reroll)
        giveawayChannel.send({ embeds: [embed], components: [row] })
        m.edit({ embeds: [endedEmbedGiveaway] });
      }, duration_time);

      client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;
        //reroll button
        if (interaction.customId === 'reroll') {
          let winner = m.reactions.cache.get("🎉").users.cache.filter((users) => !users.bot).random(winnerCount.toString().slice(0, -1));
          const noperms = new MessageEmbed()
            .setAuthor({ name: message.channel.guild.name, iconURL: message.channel.guild.iconURL({ dynamic: true }) })
            .setColor(config.color)
            .setDescription(`**Δεν μπορείς να κανείς Reroll**`)
          if (!interaction.member.permissions.has('ADMINISTRATOR')) return interaction.reply({ embeds: [noperms], ephemeral: true })
          const embed = new MessageEmbed()
            .setTitle("Giveaway Rerolled")
            .setDescription(`**ο/οι νικητής/νικητές του Giveaway είναι: ${winner}**`)
            .setColor(config.color)
            .setFooter(`Rerolled By : ${interaction.user.tag}`)
          const reroll = new MessageButton()
            .setEmoji("🔁")
            .setStyle("SECONDARY")
            .setLabel("Reroll")
            .setCustomId("reroll")
          const row = new MessageActionRow()
            .addComponents(reroll)
          interaction.reply({ embeds: [embed], components: [row] })
          interaction.message.edit({ components: [] })
          const endedEmbedGiveaway = new MessageEmbed()
            .setAuthor({ name: message.channel.guild.name, iconURL: message.channel.guild.iconURL({ dynamic: true }) })
            .setThumbnail(message.channel.guild.iconURL({ dynamic: true }))
            .setDescription("```" + `${prize}` + "```\n" + " > ***Κάντε reaction στο 🎉 για να συμμετάσχετε στο giveaway!***\n\n" + `**Πήραν μέρος:** \`${m.reactions.cache.get("🎉").count - 1}\`\n` + `**Hosted από τον/την:** <@${message.author.id}>\n` + `**Νικητής:** ${winner}`)
            .setColor(config.color)
            .setTimestamp(Date.now() + duration_time)

          m.edit({ embeds: [endedEmbedGiveaway] });
        }
      })
    })
  }

  if (command === 'e') {
    if (!message.member.permissions.has('ADMINISTRATOR')) return;

    message.delete()
    message.channel.send(`@everyone`).then((sent) => sent.delete());
  }

})



//add emoji

client.on('messageCreate', async message => {
  if (message.content.indexOf(prefix) !== 0) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();

  if (command === 'addemoji') {
    if (message.author.bot) return;
    if (!message.member.permissions.has('ADMINISTRATOR')) return message.reply("**You do not have permissions.**")
    if (!args.length) return message.channel.send('?')


    for (const emojis of args) {
      const getEmoji = Discord.Util.parseEmoji(emojis);

      if (getEmoji.id) {
        const emojiExt = getEmoji.animated ? ".gif" : ".png";
        const emojiURL = `https://cdn.discordapp.com/emojis/${getEmoji.id + emojiExt}`;
        message.guild.emojis
          .create(emojiURL, getEmoji.name)
          .then(emoji =>
            message.channel.send({ content: `${emoji}` }))

      }
    }
  }
})


//Ticket System
client.on('messageCreate', message => {
  if (message.content.toLowerCase() === '!ticket') {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      message.delete()
    }
    else {
      message.delete()
      const embed = new MessageEmbed()
        .setAuthor(config.name, config.logo)
        .setDescription(' ```Για την καλύτερη εξυπηρέτησή σας, επιλέξτε το είδος του Ticket που σας ενδιαφέρει και κάποιο μέλος του προσωπικού μας θα σας εξυπηρετήσει άμεσα.``` ')
        .setThumbnail(config.logo)
        .setColor(config.color);
      const row = new MessageActionRow()
        .addComponents(
          new MessageSelectMenu()
            .setCustomId("category")
            .setPlaceholder("Πάτα εδώ για να ορίσεις το θέμα του Ticket.")
            .addOptions([{
              label: 'Owner',
              value: '👑Owner',
              description: 'Ticket To Talk With Owner.',
              emoji: '<:SeasideLogo:1244231913615528006> ',
            },
            {
              label: 'Buy',
              value: '💸Buy',
              description: 'Ticket To Buy.',
              emoji: '<a:72389moneywings:1244298388984299550> ',
            },
            {
              label: 'Other',
              value: '❓Other',
              description: 'Ticket For Other Stuff.',
              emoji: '<:Question:1245681704023232512>',
            },
            ]),
        );

      message.channel.send({ embeds: [embed], components: [row] })
    }
  }
})
////////////////////////////////////////////////////////////////
client.on('interactionCreate', async interaction => {
  if (!interaction.isSelectMenu()) return;
  if (interaction.values[0] === '💸Buy') {
    const get = db.get(`ticketlimit_${interaction.user.id}`)
    const embed = new MessageEmbed()
      .setAuthor(config.name, config.logo)
      .setDescription(`**Για να ανοίξετε κάποιο ticket πατήστε παρακάτω και θα σας εξυπηρετήσουμε άμεσα.**`)
      .setTitle(`Ticket | Επικοινωνήστε μαζί μας`)
      .setThumbnail(config.logo)
      .setColor(config.color);
    const limembe = new MessageEmbed()
      .setTitle("🛡️Ασφάλεια🛡️ | Ticket Limit")
      .setColor(config.color)
      .setDescription(`ο/η ${interaction.user} προσπαθεί να ανοίξει δεύτερο Ticket.`)
    const limit_embed = new MessageEmbed()
      .setColor(config.color)
      .setTitle("Ticket Limit")
      .setDescription("**__Έχεις ήδη ένα Ticket ανοιχτό.__**")
    if (get === true) return interaction.message.edit({}), interaction.reply({ embeds: [limit_embed], components: [], ephemeral: true }), client.channels.cache.get(config.ticketlogs).send({ embeds: [limembe] })
    interaction.message.edit({})
    interaction.guild.channels.create(`${interaction.values}-${interaction.user.username}`, { //ticket_name
      parent: config.ticketparent,
      topic: interaction.user.id,
      permissionOverwrites: [{
        id: interaction.user.id,
        allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
      },
      {
        id: config.ticketrole,
        allow: ['SEND_MESSAGES', 'VIEW_CHANNEL'],
      },
      {
        id: config.ticketrole1,
        allow: ['SEND_MESSAGES', 'VIEW_CHANNEL'],
      },
      {
        id: interaction.guild.roles.everyone,
        deny: ['VIEW_CHANNEL'],
      },
      ],
      type: 'text',
    }).then(async c => {
      const success = new MessageEmbed()
        .setDescription(`**✅ | Το Ticket σου δημιουργήθηκε με επιτυχία. | ${c}**`)
        .setColor(config.color)
        .setAuthor(config.name, config.logo)
      interaction.reply({ embeds: [success], components: [], ephemeral: true })
      const embed = new MessageEmbed()
        .setDescription('```Περιμένετε μέχρι ένα μέλος του προσωπικού να σε εξυπηρετήσει.Μέχρι τότε πείτε μας τι χρειάζεστε.```')
        .setFooter('Για να κλείσεις το Ticket πάτα το "🔒Close"')
        .setColor(config.color)
        .setAuthor(interaction.user.tag + " ● " + interaction.values, interaction.user.displayAvatarURL())
    .setThumbnail(`https://cdn.discordapp.com/icons/775048944748724264/9c0cc38ce02359797566259c3f759ff2.png?size=1024&format=webp&quality=lossless&width=0&height=256`)
      const closebutton = new MessageButton()
        .setStyle('SECONDARY')
        .setLabel('\🔒Close')
        .setCustomId('ticket_close');
      const row = new MessageActionRow()
        .addComponents(closebutton)
      c.send({ embeds: [embed], components: [row] })
      const log_embed = new MessageEmbed()
        .setTitle("🔨Δημιουργία Ticket🔨")
        .setThumbnail("https://cdn.discordapp.com/icons/775048944748724264/9c0cc38ce02359797566259c3f759ff2.png?size=1024&format=webp&quality=lossless&width=0&height=256")
        .setDescription(`ㅤ\n⚬ Άνοιξε από τον/ην : ${interaction.user}\n\n⚬ Θέμα : ${interaction.values}\n\n⚬ Κανάλι : <#${c.id}>`)
        .setColor(config.color)
      client.channels.cache.get(config.ticketlogs).send({ embeds: [log_embed] })
      c.send({ content: `<@&${config.ticketrole}>` }).then(msg => {
        msg.delete();
      })
      c.send({ content: `${interaction.user}` }).then(msg => {
        msg.delete();
      })
      db.set(`ticketlimit_${interaction.user.id}`, true)
    })

  }

  //
  if (interaction.values[0] === '❓Other') {
    const get = db.get(`ticketlimit_${interaction.user.id}`)
    const embed = new MessageEmbed()
      .setAuthor(config.name, config.logo)
      .setDescription(`**Για να ανοίξετε κάποιο ticket πατήστε παρακάτω και θα σας εξυπηρετήσουμε άμεσα.**`)
      .setTitle(`Ticket | Επικοινωνήστε μαζί μας`)
      .setThumbnail(config.logo)
      .setColor(config.color);
    const limembe = new MessageEmbed()
      .setTitle("🛡️Ασφάλεια🛡️ | Ticket Limit")
      .setColor(config.color)
      .setDescription(`ο/η ${interaction.user} προσπαθεί να ανοίξει δεύτερο Ticket.`)
    const limit_embed = new MessageEmbed()
      .setColor(config.color)
      .setTitle("Ticket Limit")
      .setDescription("**__Έχεις ήδη ένα Ticket ανοιχτό.__**")
    if (get === true) return interaction.message.edit({}), interaction.reply({ embeds: [limit_embed], components: [], ephemeral: true }), client.channels.cache.get(config.ticketlogs).send({ embeds: [limembe] })
    interaction.message.edit({})
    interaction.guild.channels.create(`${interaction.values}-${interaction.user.username}`, { //ticket_name
      parent: config.ticketparent,
      topic: interaction.user.id,
      permissionOverwrites: [{
        id: interaction.user.id,
        allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
      },
      {
        id: config.ticketrole,
        allow: ['SEND_MESSAGES', 'VIEW_CHANNEL'],
      },
      {
        id: config.ticketrole1,
        allow: ['SEND_MESSAGES', 'VIEW_CHANNEL'],
      },
      {
        id: interaction.guild.roles.everyone,
        deny: ['VIEW_CHANNEL'],
      },
      ],
      type: 'text',
    }).then(async c => {
      const success = new MessageEmbed()
        .setDescription(`**✅ | Το Ticket σου δημιουργήθηκε με επιτυχία. | ${c}**`)
        .setColor(config.color)
        .setAuthor(config.name, config.logo)
      interaction.reply({ embeds: [success], components: [], ephemeral: true })
      const embed = new MessageEmbed()
        .setDescription('```Describe your problem in detail and wait for a staff member to serve you.```')
        .setFooter('Για να κλείσεις το Ticket πάτα το "🔒Close"')
        .setColor(config.color)
        .setAuthor(interaction.user.tag + " ● " + interaction.values, interaction.user.displayAvatarURL())
    .setThumbnail(`https://cdn.discordapp.com/icons/775048944748724264/9c0cc38ce02359797566259c3f759ff2.png?size=1024&format=webp&quality=lossless&width=0&height=256`)
      const closebutton = new MessageButton()
        .setStyle('SECONDARY')
        .setLabel('\🔒Close')
        .setCustomId('ticket_close');
      const row = new MessageActionRow()
        .addComponents(closebutton)
      c.send({ embeds: [embed], components: [row] })
      const log_embed = new MessageEmbed()
        .setTitle("🔨Δημιουργία Ticket🔨")
        .setThumbnail("https://cdn.discordapp.com/icons/775048944748724264/9c0cc38ce02359797566259c3f759ff2.png?size=1024&format=webp&quality=lossless&width=0&height=256")
        .setDescription(`ㅤ\n⚬ Άνοιξε από τον/ην : ${interaction.user}\n\n⚬ Θέμα : ${interaction.values}\n\n⚬ Κανάλι : <#${c.id}>`)
        .setColor(config.color)
      client.channels.cache.get(config.ticketlogs).send({ embeds: [log_embed] })
      c.send({ content: `<@&${config.ticketrole}>` }).then(msg => {
        msg.delete();
      })
      c.send({ content: `${interaction.user}` }).then(msg => {
        msg.delete();
      })
      db.set(`ticketlimit_${interaction.user.id}`, true)
    })

  }
  //
  if (interaction.values[0] === '👑Owner') {
    const get = db.get(`ticketlimit_${interaction.user.id}`)
    const embed = new MessageEmbed()
      .setAuthor(config.name, config.logo)
      .setDescription(`**Για να ανοίξετε κάποιο ticket πατήστε παρακάτω και θα σας εξυπηρετήσουμε άμεσα.**`)
      .setTitle(`Ticket | Επικοινωνήστε μαζί μας`)
      .setThumbnail(config.logo)
      .setColor(config.color);
    const limembe = new MessageEmbed()
      .setTitle("🛡️Ασφάλεια🛡️ | Ticket Limit")
      .setColor(config.color)
      .setDescription(`ο/η ${interaction.user} προσπαθεί να ανοίξει δεύτερο Ticket.`)
    const limit_embed = new MessageEmbed()
      .setColor(config.color)
      .setTitle("Ticket Limit")
      .setDescription("**__Έχεις ήδη ένα Ticket ανοιχτό.__**")
    if (get === true) return interaction.message.edit({}), interaction.reply({ embeds: [limit_embed], components: [], ephemeral: true }), client.channels.cache.get(config.ticketlogs).send({ embeds: [limembe] })
    interaction.message.edit({})
    interaction.guild.channels.create(`${interaction.values}-${interaction.user.username}`, { //ticket_name
      parent: config.ticketparent,
      topic: interaction.user.id,
      permissionOverwrites: [{
        id: interaction.user.id,
        allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
      },
      {
        id: interaction.guild.roles.everyone,
        deny: ['VIEW_CHANNEL'],
      },
      ],
      type: 'text',
    }).then(async c => {
      const success = new MessageEmbed()
        .setDescription(`**✅ | Το Ticket σου δημιουργήθηκε με επιτυχία. | ${c}**`)
        .setColor(config.color)
        .setAuthor(config.name, config.logo)
      interaction.reply({ embeds: [success], components: [], ephemeral: true })
      const embed = new MessageEmbed()
        .setDescription('```Περιέγραψε αναλυτικά το πρόβλημα σου και περίμενε μέχρι ένα μέλος του προσωπικού να σε εξυπηρετήσει.```')
        .setFooter('Για να κλείσεις το Ticket πάτα το "🔒Close"')
        .setColor(config.color)
        .setAuthor(interaction.user.tag + " ● " + interaction.values, interaction.user.displayAvatarURL())
    .setThumbnail(`https://cdn.discordapp.com/icons/775048944748724264/9c0cc38ce02359797566259c3f759ff2.png?size=1024&format=webp&quality=lossless&width=0&height=256`)
      const closebutton = new MessageButton()
        .setStyle('SECONDARY')
        .setLabel('\🔒Close')
        .setCustomId('ticket_close');
      const row = new MessageActionRow()
        .addComponents(closebutton)
      c.send({ embeds: [embed], components: [row] })
      const log_embed = new MessageEmbed()
        .setTitle("🔨Δημιουργία Ticket🔨")
        .setThumbnail("https://cdn.discordapp.com/icons/775048944748724264/9c0cc38ce02359797566259c3f759ff2.png?size=1024&format=webp&quality=lossless&width=0&height=256")
        .setDescription(`ㅤ\n⚬ Άνοιξε από τον/ην : ${interaction.user}\n\n⚬ Θέμα : ${interaction.values}\n\n⚬ Κανάλι : <#${c.id}>`)
        .setColor(config.color)
      client.channels.cache.get(config.ticketlogs).send({ embeds: [log_embed] })
      c.send({ content: `<@&${config.ticketrole}>` }).then(msg => {
        msg.delete();
      })
      c.send({ content: `${interaction.user}` }).then(msg => {
        msg.delete();
      })
      db.set(`ticketlimit_${interaction.user.id}`, true)
    })

  }
  ///////////Telos Apo Values
})
/////////////////////////////////
/////////////////////////////////
//ticket close
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'ticket_close') {
    const get = db.get(`force-close`, true)
    const log_embed = new MessageEmbed()
      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .setDescription(`**\`${interaction.channel.name}\` ● \`${interaction.channel.id}\`**`)
      .setColor('RED')

    if (get === true) return client.channels.cache.get(config.ticketlogs).send({ embeds: [log_embed] }), db.set(`ticketlimit_${interaction.user.id}`, false), interaction.channel.delete().catch(() => { })
    client.channels.cache.get(config.ticketlogs).send({ embeds: [log_embed] })
    db.set(`ticketlimit_${interaction.channel.topic}`, false)
    interaction.channel.delete().catch(() => { })
  }
  //telos
})
//

//remove limit command
client.on('messageCreate', async (message) => {
  if (message.author.bot) return
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  if (command === 'removelimit') {
    if (!message.member.permissions.has("ADMINISTRATOR")) return;
    const member = message.mentions.users.first()
    if (!member) return message.channel.send(`**Κάνε Tag το Member**`)  
    db.set(`ticketlimit_${member.id}`, false)
    message.channel.send(`👍 | ${member} Now you can open Ticket`)

  }
})
//force close command

client.on("messageCreate", async message => {
  if (message.content.startsWith("!force on")) {
    if (!message.member.permissions.has("ADMINISTRATOR")) return message.channel.send({ content: "**Χρειάζεται να έχεις Administrator**" })
    db.set(`force-close`, true)
    message.channel.send({ content: "✅Force Close : On" })
  }
})
client.on("messageCreate", async message => {
  if (message.content.startsWith("!force off")) {
    if (!message.member.permissions.has("ADMINISTRATOR")) return message.channel.send({ content: "**Χρειάζεται να έχεις Administrator**" })
    db.set(`force-close`, false)
    message.channel.send({ content: "✅Force Close : Off" })
  }
})


/////////////////////////// !Pay //////////////////////////////////////////////
client.on("messageCreate", async message => {
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  if (command === "pay") {
    if (!message.member.permissions.has("ADMINISTRATOR")) { }
    const payment = new MessageEmbed()
      //.setAuthor(config.name, config.logo)
      .setColor(config.color)
      .setThumbnail(config.logo)
      .setTitle('PayPal email --> Email: stefanoulhs121@gmail.com')
      .setDescription('```F&F, No notes, Send screenshot for proof`````')
    message.channel.send({ embeds: [payment] }).then(m => message.delete({ timeout: 1500 }))
  }
})

client.on("messageCreate", async message => {
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  if (command === "ppth") {
    if (!message.member.permissions.has("ADMINISTRATOR")) { }
    const payment = new MessageEmbed()
      //.setAuthor(config.name, config.logo)
      .setColor(config.color)
      .setThumbnail(config.logo)
      .setTitle('PayPal email --> Email: paypal email')
      .setDescription('F&F, No notes, Send screenshot for proof')
    message.channel.send({ embeds: [payment] }).then(m => message.delete({ timeout: 1500 }))
  }
})


//////////////////////////////////////////////////////////////////////////////// Server Stats //////////////////////////////////////////////////////////
client.on("ready", function() {

  if (config.TOTAL_MEMBERS) {
    const total = client.guilds.cache.get(config['GUILD-ID']).channels.cache.get(config.TOTAL_MEMBERS)
    if (total) {
      setInterval(() => {
        total.setName(`🕺User's: ${client.guilds.cache.get(config['GUILD-ID']).memberCount}`).catch(() => { });
      }, 5000)
    }
  }
  if (config.BOOSTS) {
    const boost = client.guilds.cache.get(config['GUILD-ID']).channels.cache.get(config.BOOSTS)
    if (boost) {
      setInterval(() => {
        boost.setName(`🔮Boosts: ${client.guilds.cache.get(config['GUILD-ID']).premiumSubscriptionCount}`).catch(() => { });
      }, 5000)
    }
  }

})



    //verify system

    const verify_role = config.verify
    client.on("messageCreate", async message => {
      if (message.content.startsWith("!verify")) {
        if (!message.member.permissions.has("ADMINISTRATOR")) return message.channel.send("**Χρειάζεται να έχεις Administrator**")
        const embed = new MessageEmbed()
          //.setAuthor(config.name,config.logo)
          .setThumbnail(config.logo)
          .setDescription("** > Welcome To The Server, Please Verify To Continue Your Visit.**")
          .setColor(config.color)
        const koumpi = new MessageButton()
          .setEmoji("⚪")
          .setStyle("SECONDARY")
          .setLabel("Verify")
          .setCustomId("role")
        const row = new MessageActionRow()
          .addComponents(koumpi)
        message.channel.send({ embeds: [embed], components: [row] })
      }
    })
    client.on('interactionCreate', async interaction => {
      if (!interaction.isButton()) return;
      if (interaction.customId === 'role') {
        interaction.member.roles.add(verify_role)
        interaction.reply({ content: `**The role has been added to you: **<@&${verify_role}>`, ephemeral: true })
        const embed = new MessageEmbed()
          .setTitle("Verify Logs")
          .setColor("Blurple")
          .setDescription(`${interaction.member} has been verified`)
        client.channels.cache.get(config.verifylogs).send({ embeds: [embed] })
      }
    })





///\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\             Feedback System      ///\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
client.on("messageCreate", async message => {
  if (message.content.startsWith("!feedback")) {
    if (!message.member.permissions.has('ADMINISTRATOR')) return message.reply("**You do not have permissions.**")
    const embed = new MessageEmbed()
      .setColor(config.color)
      //.setAuthor(config.name,config.logo)
      .setTitle(`**Για να κάνετε feedback πατήστε το 📝
**`)
    .setThumbnail(`https://cdn.discordapp.com/attachments/1243843867439267891/1244203875775545425/Screenshot_2024-05-16_215659.png?ex=665988a8&is=66583728&hm=168a7838126bdcc394ab4c555827b682eb1cb70f6d0800097635583273bcd4fc&`)
    const button = new MessageButton()
      .setEmoji("📝")
      .setStyle("SECONDARY")
      .setCustomId("feedback")
    const row = new MessageActionRow()
      .addComponents(button)
    message.delete()
    message.channel.send({ embeds: [embed], components: [row] })
  }
})
client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'feedback') {
      const modal = new Modal()
        .setCustomId('feedback_modal')
        .setTitle(`${config.name} | Feedback`)
        .addComponents([
          new MessageActionRow().addComponents(
            new TextInputComponent()
              .setCustomId('feedback_input')
              .setLabel('Your Feedback')
              .setStyle('PARAGRAPH')
              .setMinLength(5)
              .setMaxLength(45)
              .setPlaceholder('Ανέφερε το feedback σου εδώ')
              .setRequired(true),
          ),


        ]);

      await interaction.showModal(modal);
    }
  }

  if (interaction.isModalSubmit()) {
    if (interaction.customId === 'feedback_modal') {
      const embed2 = new MessageEmbed()
        .setAuthor(config.name, config.logo)
        .setColor(config.color)
        .setDescription("**Το Feedback σου στάλθηκε**")
      interaction.reply({ embeds: [embed2], ephemeral: true })
      const response = interaction.fields.getTextInputValue('feedback_input')
      const embed = new MessageEmbed()
        .setAuthor(interaction.user.tag, interaction.user.displayAvatarURL())
        .setDescription(`**Feedback :** ${response}`)
        .setColor(config.color)
        .setTimestamp()
  .setThumbnail(`https://cdn.discordapp.com/attachments/1243843867439267891/1244203875775545425/Screenshot_2024-05-16_215659.png?ex=665988a8&is=66583728&hm=168a7838126bdcc394ab4c555827b682eb1cb70f6d0800097635583273bcd4fc&`)
      client.channels.cache.get(config.feedback_channel).send({ embeds: [embed] })

    }
  }
});




//Advan  ce Application System With Modal
client.on('messageCreate', message => {
  if (message.content.toLowerCase() === '!appmodal') {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      message.delete()
    }
    else {
      message.delete()
      const embed = new MessageEmbed()
        .setAuthor(config.name, config.logo)
        .setDescription(`**Για να μπεις Staff στον Server μας πατα το παρακάτω κουμπί !**`)
        .setThumbnail(config.logo)
        .setColor(config.color);
      const ticketopen = new MessageButton()
        .setStyle('SECONDARY')
        .setLabel('💼')
        .setCustomId('apptmodal');
      const row = new MessageActionRow()
        .addComponents(ticketopen)

      message.channel.send({ embeds: [embed], components: [row] })
    }
  }
})
///////////
client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'apptmodal') {
      const get = db.get(`applimit2_${interaction.user.id}`)
      const embed = new MessageEmbed()
        .setTitle("Application Limit")
        .setDescription("**Έχεις ήδη ένα Application υπό επεξεργασία.**")
        .setColor(config.color)
      if (get === true) return interaction.reply({ embeds: [embed], ephemeral: true })
      const modal = new Modal()
        .setCustomId('app_modal')
        .setTitle(`Application | ${interaction.user.username}`)
        .addComponents([
          new MessageActionRow().addComponents(
            new TextInputComponent()
              .setCustomId('appmodal_input_1')
              .setLabel(config.modal.e1)
              .setStyle('SHORT')
              .setMinLength(1)
              .setMaxLength(200)
              .setPlaceholder('Γράψε την απάντηση σου εδώ')
              .setRequired(true),
          ),
          ///////
          new MessageActionRow().addComponents(
            new TextInputComponent()
              .setCustomId('appmodal_input_2')
              .setLabel(config.modal.e2)
              .setStyle('SHORT')
              .setMinLength(1)
              .setMaxLength(200)
              .setPlaceholder('Γράψε την απάντηση σου εδώ')
              .setRequired(true),
          ),
          ///////////
          new MessageActionRow().addComponents(
            new TextInputComponent()
              .setCustomId('appmodal_input_3')
              .setLabel(config.modal.e3)
              .setStyle('SHORT')
              .setMinLength(1)
              .setMaxLength(200)
              .setPlaceholder('Γράψε την απάντηση σου εδώ')
              .setRequired(true),
          ),
          ///////////
          new MessageActionRow().addComponents(
            new TextInputComponent()
              .setCustomId('appmodal_input_4')
              .setLabel(config.modal.e4)
              .setStyle('SHORT')
              .setMinLength(1)
              .setMaxLength(200)
              .setPlaceholder('Γράψε την απάντηση σου εδώ')
              .setRequired(true),
          ),
          ///////////
          new MessageActionRow().addComponents(
            new TextInputComponent()
              .setCustomId('appmodal_input_5')
              .setLabel(config.modal.e5)
              .setStyle('SHORT')
              .setMinLength(1)
              .setMaxLength(200)
              .setPlaceholder('Γράψε την απάντηση σου εδώ')
              .setRequired(true),
          ),

        ]);

      await interaction.showModal(modal);
    }
  }

  if (interaction.isModalSubmit()) {
    if (interaction.customId === 'app_modal') {
      const response1 = interaction.fields.getTextInputValue('appmodal_input_1')
      const response2 = interaction.fields.getTextInputValue('appmodal_input_2')
      const response3 = interaction.fields.getTextInputValue('appmodal_input_3')
      const response4 = interaction.fields.getTextInputValue('appmodal_input_4')
      const response5 = interaction.fields.getTextInputValue('appmodal_input_5')
      const embed2 = new MessageEmbed()
        .setAuthor(config.name, config.logo)
        .setColor(config.color)
        .setDescription("**Το Application σου στάλθηκε.**")
      interaction.reply({ embeds: [embed2], ephemeral: true })


      interaction.guild.channels.create(`💼-${interaction.user.username}`, { //ticket_name
        parent: config.modal.appmodal_parent,
        topic: interaction.user.id,
        permissionOverwrites: [{
          id: interaction.user.id,
          deny: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
        },
        {
          id: config.modal.appmodal_role,
          allow: ['SEND_MESSAGES', 'VIEW_CHANNEL'],
        },
        {
          id: interaction.guild.roles.everyone,
          deny: ['VIEW_CHANNEL'],
        },
        ],
        type: 'text',
      }).then(async c => {

        const embed = new MessageEmbed()
          .setDescription(`**Application From : ${interaction.member} | ${interaction.user.username}\n\nUser Id : ${interaction.member.id}\n----------------------------------------**`)
          .addFields(
            { name: `${config.e1}`, value: `\`${response1}\``, inline: false },
            { name: `${config.e2}`, value: `\`${response2}\``, inline: false },
            { name: `${config.e3}`, value: `\`${response3}\``, inline: false },
            { name: `${config.e4}`, value: `\`${response4}\``, inline: false },
            { name: `${config.e5}`, value: `\`${response5}\``, inline: false },
          )
          .setColor(config.color)
          .setTimestamp()
          .setAuthor(interaction.user.tag, interaction.user.displayAvatarURL())
        const accept = new MessageButton()
          .setStyle('SUCCESS')
          .setLabel('✅')
          .setCustomId('accept_modal');
        const decline = new MessageButton()
          .setStyle('DANGER')
          .setLabel('❌')
          .setCustomId('decline_modal');
        const row = new MessageActionRow()
          .addComponents(accept)
          .addComponents(decline)
        c.send({ embeds: [embed], components: [row] })


        c.send({ content: `<@&${config.appmodal_role}>` }).then(msg => {
          msg.delete();
        })

        db.set(`applimit2_${interaction.user.id}`, true)

      })
      //
    }
  }
});
//ticket modal close
client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'accept_modal') {
      interaction.reply({ ephemeral: true }).catch(() => { })
      db.set(`applimit2_${interaction.channel.topic}`, false)
      const accept = new MessageEmbed()
        .setColor("GREEN")
        .setDescription("**Η αίτηση σου έγινε δεκτή.**")
      client.users.cache.get(interaction.channel.topic).send({ embeds: [accept] })
      const log = new MessageEmbed()
        .setTitle("Application Accepted")
        .setColor("GREEN")
        .setDescription(`Από τον/την : ${interaction.user}\nApplication από τον/την : <@${interaction.channel.topic}>`)
      client.channels.cache.get(config.appmodal_logs).send({ embeds: [log] })
      interaction.channel.delete().catch(() => { })
    }

    if (interaction.customId === 'decline_modal') {
      interaction.reply({ ephemeral: true }).catch(() => { })
      db.set(`applimit2_${interaction.channel.topic}`, false)
      const accept = new MessageEmbed()
        .setColor("RED")
        .setDescription("**Η αίτηση σου δεν έγινε δεκτή.**")
      client.users.cache.get(interaction.channel.topic).send({ embeds: [accept] })
      const log2 = new MessageEmbed()
        .setTitle("Application Declined")
        .setColor("RED")
        .setDescription(`Από τον/την : ${interaction.user}\nApplication από τον/την : <@${interaction.channel.topic}>`)
      client.channels.cache.get(config.logs.appmodal_logs).send({ embeds: [log2] })
      interaction.channel.delete().catch(() => { })
    }
  }
})

//////////////////////////////////clear command///////////////////////////////////////////
client.on('messageCreate', async (message) => {
  if (message.author.bot) return
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  if (message.content.startsWith('!c')) {
    if (!message.member.permissions.has("ADMINISTRATOR")) return message.reply("**You do not have permissions.**")
    const content = args.join(' ');
    if (!content) return message.channel.send("How many messages do you want to delete ?")
    message.channel.bulkDelete(content).catch(e => { message.channel.send('Δεν μπορείς να σβήσεις τόσο παλιά μηνύματα .') })

  }
})



client.on('guildMemberAdd', (member) => {
  const user = member.user
  const channelID = member.guild.channels.cache.get(config.logs.joinlogs)
  const guild = member.guild.id
  const memberEmbed = new Discord.MessageEmbed()
    .setAuthor(member.user.username, member.user.displayAvatarURL(), "https://discord.com/users/" + member.user.id)
    .setDescription(` \`\`\` Join \`\`\` \n**Register**: \`${moment(member.user.createdAt).format("MMM Do YYYY").toLocaleString()}\`\n**Mention:** <@!${member.user.id}>`)
    .setColor('GREEN')
  const role = member.guild.roles.cache.get(config.logs.autorole)//auto role
  member.roles.add(role).catch(() => { })
  channelID.send({ embeds: [memberEmbed] })
})
client.on('guildMemberRemove', (member) => {
  const monitorID = member.guild.channels.cache.get(config.logs.leavelogs)//left logs
  const guild = member.guild.id
  const memberEmbed = new Discord.MessageEmbed()
    .setColor('RED')
    .setDescription(` \`\`\` Leave \`\`\` \n**Register**: \`${moment(member.user.createdAt).format("MMM Do YYYY").toLocaleString()}\`\n**Mention:** <@!${member.user.id}>`)
    .setAuthor(member.user.username, member.user.displayAvatarURL(), "https://discord.com/users/" + member.user.id)
    .setImage('')
  monitorID.send({ embeds: [memberEmbed] })
})
////// Message Edit Logs \\\\\\
client.on("messageUpdate", async (oldMessage, newMessage) => {
  try {
    if (newMessage.author.bot) return
    let channel = oldMessage.guild.channels.cache.get(config.logs.msglogs)
    const url = oldMessage.url
    const embed = new Discord.MessageEmbed()
      .setTitle(`Edited Message Logs`)
      .setColor('#0084fd')
      .setTimestamp()
      .setURL(url)
      .addField(`Παλιο μυνημα`, `*${oldMessage.content}*`, false)
      .addField(`Τελικο μυνημα`, `*${newMessage.content}*`, false)
      .addField(`Το μυνημα ειναι του`, `**<@${oldMessage.author.id}>**`, true)
      .addField(`Καναλι που ηταν το μυνημα`, `**<#${oldMessage.channel.id}>**`, true)
    channel.send({ embeds: [embed] }).catch(() => { })
  } catch {

  }
})
var temporary = [];

////// Message Delete \\\\\\
client.on('messageDelete', async message => {
  if (!message.guild) return;
  const fetchedLogs = await message.guild.fetchAuditLogs({
    limit: 1,
    type: 'MESSAGE_DELETE',
  });
  const deletionLog = fetchedLogs.entries.first();
  const embed = new Discord.MessageEmbed({
    "author": {
      "name": message.author.tag,
      "url": "https://discord.com/users/" + message.author.id,
      "icon_url": message.author.displayAvatarURL()
    },
    "color": 15483204,
    "description": "​\n" + message.content + "\n\n**Author : <@" + message.author.id + ">\nChannel : <#" + message.channel.id + ">**"
  })
  if (!deletionLog) return client.channels.cache.get(config.logs.msglogs).send({ embeds: [embed] })

  const { executor, target } = deletionLog;
  const embed2 = new Discord.MessageEmbed({
    "author": {
      "name": message.author.tag,
      "url": "https://discord.com/users/" + message.author.id,
      "icon_url": message.author.displayAvatarURL()
    },
    "color": 15483204,
    "description": "​\n" + message.content + "\n\n**Author : <@" + message.author.id + ">\nChannel : <#" + message.channel.id + ">**\n**Deleted By : <@" + executor.id + ">**"
  })
  const embed3 = new Discord.MessageEmbed({
    "author": {
      "name": message.author.tag,
      "url": "https://discord.com/users/" + message.author.id,
      "icon_url": message.author.displayAvatarURL()
    },
    "color": 15483204,
    "description": "​\n" + message.content + "\n\n**Author : <@" + message.author.id + ">\nChannel : <#" + message.channel.id + ">**"
  })
  try {
    if (target.id == message.author.id) {
      client.channels.cache.get(config.logs.msglogs).send({ embeds: [embed2] }).catch(() => { })
    } else {
      client.channels.cache.get(config.logs.msglogs).send({ embeds: [embed3] }).catch(() => { })
    }
  } catch {

  }
});

//voice logs
var temporary = [];
client.on('voiceStateUpdate', (oldMember, newMember) => {
  let newUserChannel = newMember.channelId;
  let oldUserChannel = oldMember.channelId;


  try {
    if (newUserChannel) {
      const voicelogs = newMember.guild.channels.cache.get(config.logs.voicelogs)
      const voicee = new Discord.MessageEmbed({
        "author": {
          "name": newMember.member.user.tag,
          "url": "https://discord.com/users/" + newMember.member.user.id,
          "icon_url": newMember.member.user.displayAvatarURL()
        },
        "color": 4371328,
        "description": "**Κανάλι: <#" + newUserChannel + "> • " + newMember.channel.name + "\nMention: <@" + newMember.member.user.id + ">**"
      })
      voicelogs.send({ embeds: [voicee] })
    }

    else {
      if (oldUserChannel) {
        const voicelogs = oldMember.guild.channels.cache.get(config.logs.voicelogs)
        const voice = new Discord.MessageEmbed({
          "author": {
            "name": newMember.member.user.tag,
            "url": "https://discord.com/users/" + newMember.member.user.id,
            "icon_url": newMember.member.user.displayAvatarURL()
          },
          "color": 15681608,
          "description": "**Κανάλι: <#" + oldUserChannel + "> • `" + oldMember.channel.name + "`\nMention: <@" + oldMember.member.user.id + ">**"
        })
        voicelogs.send({ embeds: [voice] })
      }
    }
  } catch {
    e => console.log(e.message)
  }
})





////// Role Create-Delete Logs \\\\\\
client.on("roleCreate", async (role) => {
  const fetchedLogs = await role.guild.fetchAuditLogs({
    limit: 1,
    type: 'ROLE_CREATE',
  });

  const fasdfa = fetchedLogs.entries.first();
  let { executor, target, reason } = fasdfa;
  if (executor === null) executor = "\u200B";
  if (target === null) target = "\u200B";
  if (reason === null) reason = "\u200B";

  const embed = new Discord.MessageEmbed()
    .setColor("GREEN")
    .setAuthor(executor.username, executor.displayAvatarURL(), `https://discord.com/users/${executor.id}`)
    .setDescription("A new role was created!")
    .addFields(
      { name: "User", value: executor.username },
      { name: "Role Name", value: target.name },
      { name: "Role ID", value: target.id },
      { name: "reason", value: reason }
    )
    // .setFooter(`Role ID: ${id}`)
    .setTimestamp();

  client.channels.cache.get(config.logs.rolelogs).send({ embeds: [embed] }).catch(() => { })
})
client.on("roleDelete", async (role) => {

  const fetchedLogs = await role.guild.fetchAuditLogs({
    limit: 1,
    type: 'ROLE_DELETE',
  });

  const fasdfa = await fetchedLogs.entries.first();
  let { executor, target, reason, a } = fasdfa;
  if (executor === null) executor = "\u200B";
  if (target === null || target === undefined) target = "\u200B";
  if (reason === null) reason = "\u200B";

  const embed = new Discord.MessageEmbed()
    .setColor("RED")
    .setAuthor(executor.username, executor.displayAvatarURL(), `https://discord.com/users/${executor.id}`)
    .setDescription("A new role was Deleted!")
    .addFields(
      { name: "User", value: executor.username },
      { name: "Role Name", value: role.name },
      { name: "Role ID", value: role.id },
      { name: "reason", value: reason }
    )
    // .setFooter(`Role ID: ${id}`)
    .setTimestamp();

  client.channels.cache.get(config.logs.rolelogs).send({ embeds: [embed] })

});
//role update
client.on('guildMemberUpdate', async function(oldMember, newMember) {
  const log = await newMember.guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_ROLE_UPDATE' }).then(logs => logs.entries.first());
  let addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
  let removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));

  if (removedRoles.size > 0) {
    const removeRoleEmbed = new Discord.MessageEmbed()
      .setColor('RED')
      .setAuthor(`${oldMember.user.tag}`, oldMember.user.avatarURL())
      .setDescription(`<@!${oldMember.id}> lost role <@&${removedRoles.map(r => r.id)}> from <@!${log.executor.id}>`)
      .setTimestamp()
      .setFooter(`ID : ${oldMember.id}`)
    client.channels.cache.get(config.logs.rolelogs).send({ embeds: [removeRoleEmbed] })
  }

  if (addedRoles.size > 0) {
    const addRoleEmbed = new Discord.MessageEmbed()
      .setColor('GREEN')
      .setAuthor(`${oldMember.user.tag}`, oldMember.user.avatarURL())
      .setDescription(`<@!${oldMember.id}> got role <@&${addedRoles.map(r => r.id)}> from <@!${log.executor.id}>`)
      .setTimestamp()
      .setFooter(`ID : ${oldMember.id}`)
    client.channels.cache.get(config.logs.rolelogs).send({ embeds: [addRoleEmbed] })
  }
});
//channel create
client.on("channelCreate", async function(channel) {
  const logs = await channel.guild.fetchAuditLogs({ limit: 1, type: 'CHANNEL_CREATE' });
  const log = logs.entries.first();
  if (!log) return;
  const embed = new Discord.MessageEmbed()
    //.setAuthor(config.logs.name, config.logs.logo)
    .setColor("GREEN")
    .setDescription(`**Author : <@!${log.executor.id}>\nChannel Name : \`${channel.name}\`\nChannel Type : \`${channel.type}\`**`)
  client.channels.cache.get(config.logs.channellogs).send({ embeds: [embed] })
});
//channel delete
client.on("channelDelete", async function(channel) {
  const logs = await channel.guild.fetchAuditLogs({ limit: 1, type: 'CHANNEL_DELETE' });
  const log = logs.entries.first();
  if (!log) return;
  const embed = new Discord.MessageEmbed()
    .setAuthor(config.name, config.logo)
    .setColor("RED")
    .setDescription(`**Author : <@!${log.executor.id}>\nChannel Name : \`${channel.name}\`\nChannel Type : \`${channel.type}\`**`)

  client.channels.cache.get(config.logs.channellogs).send({ embeds: [embed] })
});

client.on('guildMemberRemove', async member => {
  const logs = await member.guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_KICK' });
  const log = logs.entries.first();
  const { reason } = log;

  if (!log) return;
  const embed = new MessageEmbed()
    .setColor("RED")
    .setDescription(`${member.user} **kicked**\n\nΑπό τον/την : ${log.executor}\nΛόγος : ${reason || `No Reason`}`)
  if (Date.now() - log.createdTimestamp < 5000) {
    client.channels.cache.get(config.logs.kicklogs).send({ embeds: [embed] })

  }
})
//ban logs
client.on('guildBanAdd', async ban => {
  const logs = await ban.guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_BAN_ADD' });
  const log = logs.entries.first();
  const { reason } = log;
  if (!log) return;
  const embed = new MessageEmbed()
    .setColor("RED")
    .setDescription(`${ban.user} **banned**\n\nΑπό τον/την : ${log.executor}\nΛόγος : ${reason || `No Reason`}`)
  if (Date.now() - log.createdTimestamp < 5000) {
    client.channels.cache.get(config.logs.banlogs).send({ embeds: [embed] })
  }
})
//unban logs
client.on('guildBanRemove', async member => {
  const logs = await member.guild.fetchAuditLogs({ limit: 1, type: 'MEMBER_BAN_REMOVE' });
  const log = logs.entries.first();
  const { reason } = log;
  if (!log) return;
  const embed = new MessageEmbed()
    .setColor("RED")
    .setDescription(`${member.user} **unbanned**\n\nΑπό τον/την : ${log.executor}`)
  if (Date.now() - log.createdTimestamp < 5000) {
    client.channels.cache.get(config.logs.banlogs).send({ embeds: [embed] })


  }
})

client.on("guildMemberAdd", async member => {
  const channel = member.guild.channels.cache.get(config.welcomesystem)
  const welcome = new MessageEmbed()
    .setColor(config.color)
    .setDescription(`**> Welcome <@${member.id}> we hope you have a nice day \n\n > Total Members : \`${client.guilds.cache.get("1230937127949172736").memberCount}\`**`)
    .setAuthor(config.name, config.logo)
    .setThumbnail(config.logo)

  channel.send({ embeds: [welcome] })
})


//SUGGESTION SYSTEM YES
client.on('messageCreate', async message => {
  if (message.channel.id === '1245009657731219467') {
    if (message.member.user.bot) return
    message.react('<:Yes:1237088954566578317>').then(() => {
    })
  }
})

//SUGGESTION SYSTEM NO
client.on('messageCreate', async message => {
  if (message.channel.id === '1245009657731219467') {
    if (message.member.user.bot) return
    message.react('<:Arnitiko:1237088720855761018> ').then(() => {
    })
  }
})

//REACT SYSTEM
client.on('messageCreate', async message => {
  if (message.channel.id === '1237089085680652358') {
    if (message.bot) return
    message.react('<a:Heart:1237450658219823167> ').then(() => {
    })
  }
})








//Restock Ping Embed\\
client.on("messageCreate", async message => {
  if (message.content.startsWith("!restockping")) {
    if (!message.member.permissions.has('ADMINISTRATOR')) return;
    const embed = new MessageEmbed()
      .setDescription("**Choose your roles")
      .setDescription("**Press the ✅ to took Stock Ping Role!**")
      .setColor("#006aff")
      .setThumbnail(config.logo)
      .setAuthor({ name: config.name, iconURL: config.logo })
    const role1 = new MessageButton()
      .setEmoji("✅")
      .setStyle("SECONDARY")

      .setCustomId("role1")
    const buttons = new MessageActionRow()
      .addComponents(role1)
    message.channel.send({ embeds: [embed], components: [buttons] })
  }
})


//Restock Ping Roles Ids\\
client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'role1') {
    const role1 = db.get(`role1_${interaction.user.id}`)
    //
    const role1e = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`**You took the <@&${config.role1}> role**`)
    const role1e2 = new MessageEmbed()
      .setColor("Blurple")
      .setDescription(`**You removed from <@&${config.role1}> role**`)
    //
    if (role1 === true) return interaction.reply({ embeds: [role1e2], ephemeral: true }), db.set(`role1_${interaction.user.id}`, false), interaction.member.roles.remove(config.role1).catch(() => { })
    //
    db.set(`role1_${interaction.user.id}`, true)
    interaction.member.roles.add(config.role1).catch(() => { })
    interaction.reply({ embeds: [role1e], ephemeral: true })
  }
})


client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (message.content === '!serverinfo') {
    const embed = new Discord.MessageEmbed()
      .setThumbnail(config.logo)
      .setColor(config.color)
      .setAuthor(config.name, config.logo)
      .setTitle(`${message.guild.name} Server Stats`)
      .addFields(
        {
          name: "👑 Owner: ",
          value: `**<@${message.guild.ownerId}>**`,
          inline: true
        },
        {
          name: "🧑‍🤝‍🧑 Members: ",
          value: `**${message.guild.memberCount} Members**`,
          inline: true
        },
        {
          name: "🤖 Total Bots: ",
          value: `**${message.guild.members.cache.filter(m => m.user.bot).size} Bots**`,
          inline: true
        },
        {
          name: "📆 Creation Date: ",
          value: `**${message.guild.createdAt.toLocaleDateString("en-us")}**`,
          inline: true
        },
        {
          name: "Roles Count: ",
          value: `**${message.guild.roles.cache.size} Roles**`,
          inline: true,
        },
        {
          name: `✔️ Verified: `,
          value: message.guild.verified ? '**Server is verified**' : `**Server isn't verified**`,
          inline: true
        },
        {
          name: '🔮 Boosters: ',
          value: message.guild.premiumSubscriptionCount >= 1 ? `**${message.guild.premiumSubscriptionCount} Boosts**` : `**There are no boosters**`,
          inline: true
        },
        {
          name: "🎭 Emojis: ",
          value: message.guild.emojis.cache.size >= 1 ? `**${message.guild.emojis.cache.size} Emojis**` : '**There are no emojis**',
          inline: true
        }
      )
    await message.channel.send({ embeds: [embed] })
  }
})



client.once('ready', () => {

  const embed = new MessageEmbed()
    .setTitle("Bot Is Online")
    .setDescription(`Bot are in: ${client.guilds.cache.size} Server(s)\nTotal Users: ${client.users.cache.size}`)
    .setThumbnail(config.logo)
    .setColor("GREEN")
    .setTimestamp()
  client.channels.cache.get(config.logs.startuplogs).send({ embeds: [embed] })
});


client.on("messageCreate", message => {

  if (message.content.startsWith(prefix + 'dmall')) {
    message.delete
    args = message.content.split(" ").slice(1);
    var argresult = args.join(' ');

    message.guild.members.cache.forEach(member => {
      member.send(argresult).then(console.log(`[+] ${member.user.username}#${member.user.discriminator}`)).catch(e => console.error(`[-] ${member.user.username}#${member.user.discriminator}`));
    })
    console.log(`✅`)

  }

})





//Invite Tracker
const guildInvites = new Map()
client.on('inviteCreate', async invite => {
  const invites = await invite.guild.invites.fetch();

  const codeUses = new Map();
  invites.each(inv => codeUses.set(inv.code, inv.uses, inv.inviter));

  guildInvites.set(invite.guild.id, codeUses);
})

client.once('ready', () => {
  client.guilds.cache.forEach(guild => {
    guild.invites.fetch()
      .then(invites => {

        const codeUses = new Map();
        invites.each(inv => codeUses.set(inv.code, inv.uses, inv.inviter));

        guildInvites.set(guild.id, codeUses);
      })
      .catch(err => {
        console.log("OnReady Error:", err)
      })
  })
})

client.on('guildMemberAdd', async member => {
  const cachedInvites = guildInvites.get(member.guild.id)
  const newInvites = await member.guild.invites.fetch();
  try {
    const usedInvite = newInvites.find(inv => cachedInvites.get(inv.code) < inv.uses < inv.inviter);
    const embed0 = new MessageEmbed()
      .setTitle("Invite Logs")
      .setColor("GREEN")
      .setDescription(`Ο/Η ${member} (${member.user.username}) μπήκε στον server από την πρόσκληση (${usedInvite.code || "δεν υπάρχει πλέον"}) του ${usedInvite.inviter} (${usedInvite.inviter.username}) **αλλά είναι Fake**`)
    var fake22 = (Date.now() - member.user.createdAt < 1000 * 60 * 60 * config.invite_faketime * 1) //return client.channels.cache.get(config.invite_logs).send({embeds: [embed0] }),db.add(`total_${usedInvite.inviter.id}`, 1),db.add(`fake_${usedInvite.inviter.id}`, 1)
    const embed = new MessageEmbed()
      .setTitle("Invite Logs")
      .setColor("GREEN")
      .setDescription(`Ο/Η ${member} (${member.user.username}) μπήκε στον server από την πρόσκληση (${usedInvite.code || "δεν υπάρχει πλέον"}) του ${usedInvite.inviter} (${usedInvite.inviter.username})`)
    client.channels.cache.get(config.invite_logs).send({ embeds: [embed] })
    if (usedInvite.inviter) {
      db.set(`invites_${member.guild.id}.${member.id}.inviter`, usedInvite.inviter.id);
      if (fake22) {
        total = db.add(`invites_${member.guild.id}.${usedInvite.inviter.id}.total`, 1);
        _fake = db.add(`invites_${member.guild.id}.${usedInvite.inviter.id}.fake`, 1);
      }
      else {
        total = db.add(`invites_${member.guild.id}.${usedInvite.inviter.id}.total`, 1);
        regular = db.add(`invites_${member.guild.id}.${usedInvite.inviter.id}.regular`, 1);
      }
    }
    //console.log(`The code ${usedInvite.code} was just used by ${member.user.username}. ${usedInvite.inviter.username}`)
  } catch (err) {

  }

  newInvites.each(inv => cachedInvites.set(inv.code, inv.uses));
  guildInvites.set(member.guild.id, cachedInvites);
});
client.on('guildMemberRemove', async member => {
  const cachedInvites = guildInvites.get(member.guild.id)
  const newInvites = await member.guild.invites.fetch();
  try {
    const usedInvite = newInvites.find(inv => cachedInvites.get(inv.code) < inv.uses < inv.inviter);
    const embed0 = new MessageEmbed()
      .setTitle("Invite Logs")
      .setColor("RED")
      .setDescription(`Ο/Η ${member} (${member.user.username}) βγήκε από τον server. Είχε μπει από την πρόσκληση (${usedInvite.code || "δεν υπάρχει πλέον"}) του ${usedInvite.inviter} (${usedInvite.inviter.username}) **αλλά ήταν Fake**`)
    var fake22 = (Date.now() - member.user.createdAt < 1000 * 60 * 60 * config.invite_faketime * 1)//return client.channels.cache.get(config.invite_logs).send({embeds: [embed0] }),db.add(`left_${usedInvite.inviter.id}`, 1),db.subtract(`total_${usedInvite.inviter.id}`, 1),db.subtract(`fake_${usedInvite.inviter.id}`, 1)
    const embed = new MessageEmbed()
      .setTitle("Invite Logs")
      .setColor("RED")
      .setDescription(`Ο/Η ${member} (${member.user.username}) βγήκε από τον server. Είχε μπει από την πρόσκληση (${usedInvite.code || "δεν υπάρχει πλέον"}) του ${usedInvite.inviter} (${usedInvite.inviter.username})`)
    client.channels.cache.get(config.invite_logs).send({ embeds: [embed] })
    if (usedInvite.inviter) {
      db.set(`invites_${member.guild.id}.${member.id}.inviter`, usedInvite.inviter.id);
      if (fake22) {
        total = db.subtract(`invites_${member.guild.id}.${usedInvite.inviter.id}.total`, 1);
        _fake = db.subtract(`invites_${member.guild.id}.${usedInvite.inviter.id}.fake`, 1);
        db.add(`invites_${member.guild.id}.${usedInvite.inviter.id}.leave`, 1);
      }
      else {
        total = db.subtract(`invites_${member.guild.id}.${usedInvite.inviter.id}.total`, 1);
        regular = db.subtract(`invites_${member.guild.id}.${usedInvite.inviter.id}.regular`, 1);
        db.add(`invites_${member.guild.id}.${usedInvite.inviter.id}.leave`, 1);
      }
    }
    //console.log(`left The code ${usedInvite.code} was just used by ${member.user.username}. ${usedInvite.inviter.username}`)
  } catch (err) {

  }

  newInvites.each(inv => cachedInvites.set(inv.code, inv.uses));
  guildInvites.set(member.guild.id, cachedInvites);
});


client.on("message", async message => {
  //leaderboard command
  if (message.content.startsWith("!leaderboard") || message.content.startsWith("!lb")) {


    var data = db.get(`invites_${message.guild.id}`) || {};



    const guilds = Object.keys(data).map(_data => {
      return {
        Id: _data,
        Value: (data[_data].regular || 0)
      };
    }).sort((x, y) => y.Value - x.Value);

    const generateEmbed = start => {
      const current = guilds.slice(start + 0, start + 10)

      const tes = start + 10
      const embed = new MessageEmbed()

        .setAuthor(message.guild.name, message.guild.iconURL())
      db.set(`leaderboardtset_${message.guild.id}`, start)
      let content = "";

      current.forEach(g => {

        const i = db.add(`leaderboardtset_${message.guild.id}`, 1)
        content += `\`${i}.\` <@!${g.Id}> ` + config.invite_lbemoji + ` \`${g.Value}\`\n`
      }
      )

      embed.setDescription(content).setColor(config.color)
      return embed
    }




    message.channel.send({ embeds: [generateEmbed(0)] })
  }
  if (message.content.startsWith("!invites") || message.content.startsWith("!inv")) {
    var victim = message.mentions.users.first()
    //
    var data = db.get(`invites_${message.guild.id}.${message.member.id}`) || { total: 0, fake: 0, inviter: null, regular: 0, leave: 0 };
    //const left = db.get(`invites_${message.guild.id}.${victim.id}.leave`)
    var embed0 = new MessageEmbed()
      .setAuthor(message.member.user.username, message.member.user.displayAvatarURL())
      //.setDescription(`**Total : \`${(data.total || 0)}\` | Regular : \`${(data.regular || 0)}\` | Fake : \`${(data.fake || 0)}\` | Left : \`${(data.leave || 0)}\`**`)
      .setDescription(`Βρέθηκαν \`${(data.total || 0)}\` invites για τον/ην ${message.member} (**${data.regular || 0}** regular, **${data.leave || 0}** leaves, **${data.fake || 0}** fake)`)
      .setColor(config.color)
    //
    if (!victim) return message.channel.send({ embeds: [embed0] });

    var data2 = db.get(`invites_${message.guild.id}.${victim.id}`) || { total: 0, fake: 0, inviter: null, regular: 0, leave: 0 };
    //const left = db.get(`invites_${message.guild.id}.${victim.id}.leave`)
    var embed = new MessageEmbed()
      .setAuthor(victim.username, victim.displayAvatarURL(), "https://discord.com/users/" + victim.id)
      //.setDescription(`**Total : \`${(data.total || 0)}\` | Regular : \`${(data.regular || 0)}\` | Fake : \`${(data.fake || 0)}\` | Left : \`${(data.leave || 0)}\`**`)
      .setColor(config.color)
      .setDescription(`Βρέθηκαν \`${(data2.total || 0)}\` invites για τον/ην ${victim} (**${data2.regular || 0}** regular, **${data2.leave || 0}** leaves, **${data2.fake || 0}** fake)`)
    message.channel.send({ embeds: [embed] });
  }

})

/////////////////////////// !ltc //////////////////////////////////////////////
client.on("messageCreate", async message => {
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  if (command === "ltc") {
    if (!message.member.permissions.has("ADMINISTRATOR")) { }
    const payment = new MessageEmbed()
      //.setAuthor(config.name, config.logo)
      .setColor(config.color)
      .setThumbnail(config.logo)
      .setTitle('Ltc Address --> Address: Your Ltc Address')
      .setDescription('Send screenshot for proof')
    message.channel.send({ embeds: [payment] }).then(m => message.delete({ timeout: 1500 }))
  }
})


client.on('messageCreate', async message => {
  if (message.content.startsWith('!addrole')) {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      return message.channel.send('**Δεν εχεις προσβαση για αυτο το command!**');
    }

    const args = message.content.split(' ');

    if (args.length !== 3) {
      return message.channel.send('Usage: !addrole @user @role');
    }

    const userId = args[1].replace(/[<@!>]/g, ''); // Extract user ID from mention
    const roleId = args[2].replace(/[<@&>]/g, ''); // Extract role ID from mention

    try {
      // Fetch the member
      const member = await message.guild.members.fetch(userId);

      // Fetch the role
      const role = message.guild.roles.cache.get(roleId);

      if (!member) {
        return message.channel.send('**The user was not found**.');
      }

      if (!role) {
        return message.channel.send('**The role was not found**.');
      }

      // Add the role to the member
      await member.roles.add(role);
      message.channel.send(`**The role ${role.name} was added to ${member.user.tag}.**`);
    } catch (error) {
      console.error('Error adding role:', error);
      message.channel.send('There was an error adding the role.');
    }
  }
});

client.on('messageCreate', async message => {
  if (message.content.startsWith('!removerole')) {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
      return message.channel.send('**Δεν εχεις προσβαση για αυτο το command!**');
    }

    const args = message.content.split(' ');

    if (args.length !== 3) {
      return message.channel.send('Usage: !removerole @user @role');
    }

    const userId = args[1].replace(/[<@!>]/g, ''); // Extract user ID from mention
    const roleId = args[2].replace(/[<@&>]/g, ''); // Extract role ID from mention

    try {
      // Fetch the member
      const member = await message.guild.members.fetch(userId);

      // Fetch the role
      const role = message.guild.roles.cache.get(roleId);

      if (!member) {
        return message.channel.send('**The user was not found**.');
      }

      if (!role) {
        return message.channel.send('**The role was not found**.');
      }

      // Remove the role from the member
      await member.roles.remove(role);
      message.channel.send(`**The role ${role.name} was removed from ${member.user.tag}.**`);
    } catch (error) {
      console.error('Error removing role:', error);
      message.channel.send('There was an error removing the role.');
    }
  }
});

client.on('message', async (message) => {
  if (message.content.startsWith('!gungame')) {
    // Check if a user is mentioned
    const taggedUser = message.mentions.users.first();

    if (!taggedUser) {
      return message.reply('Please mention the user you want to 1V1 with.');
    }

    // Create an embed with accept and decline buttons for the tagged user
    const embed = new MessageEmbed()
      .setColor('#00FF00')
      .setTitle('GunGame 1V1')
      .setDescription(`**${message.author} has challenged ${taggedUser} to a gun game duel! Do you accept?**`)
      .setTimestamp(`10s`);

    const acceptButton = new MessageButton()
      .setCustomId('accept')
      .setLabel('Accept')
      .setStyle('SUCCESS');

    const declineButton = new MessageButton()
      .setCustomId('decline')
      .setLabel('Decline')
      .setStyle('DANGER');

    const acceptDeclineRow = new MessageActionRow()
      .addComponents(acceptButton, declineButton);

    // Send the message with the embed and buttons
    const duelInviteMessage = await message.channel.send({ embeds: [embed], components: [acceptDeclineRow] });

    // Function to handle button interactions for accepting or declining the duel
    const acceptDeclineFilter = i => ['accept', 'decline'].includes(i.customId) && i.user.id === taggedUser.id;

    const acceptDeclineCollector = duelInviteMessage.createMessageComponentCollector({ filter: acceptDeclineFilter, time: 60000 });

    acceptDeclineCollector.on('collect', async i => {
      if (i.customId === 'accept') {
        // Remove the accept/decline buttons
        acceptDeclineRow.components.forEach(component => component.setDisabled(true));
        await duelInviteMessage.edit({ content: `**${taggedUser} has accepted the gun game duel. Good Luck **`, embeds: [], components: [] });

        // Create buttons for both players to tap
        const player1Button = new MessageButton()
          .setCustomId('player1_tap')
          .setLabel('🟢')
          .setStyle('PRIMARY');

        const player2Button = new MessageButton()
          .setCustomId('player2_tap')
          .setLabel('🔴')
          .setStyle('PRIMARY');

        const tapButtonsRow = new MessageActionRow()
          .addComponents(player1Button, player2Button);

        // Send the embed with the tap buttons
        const tapMessage = await message.channel.send({ embeds: [embed], components: [tapButtonsRow] });

        // Function to handle button interactions for tapping
        const tapFilter = i => ['player1_tap', 'player2_tap'].includes(i.customId) && (i.user.id === message.author.id || i.user.id === taggedUser.id);

        const tapCollector = tapMessage.createMessageComponentCollector({ filter: tapFilter, time: 60000 });

        let countdown = 3;

        const countdownInterval = setInterval(() => {
          if (countdown > 0) {
            embed.setDescription(`Who will be the winner?\nCountdown: ${countdown}`);
            tapMessage.edit({ embeds: [embed], components: [tapButtonsRow] });
            countdown--;
          } else {
            clearInterval(countdownInterval);
            embed.setDescription(`Who will be the winner?`);
            tapMessage.edit({ embeds: [embed], components: [tapButtonsRow] });
          }
        }, 1000);

        tapCollector.on('collect', async i => {
          // Disable the tap buttons
          tapButtonsRow.components.forEach(component => component.setDisabled(true));
          await tapMessage.edit({ components: [tapButtonsRow] });

          // Determine the winner
          const winner = i.customId === 'player1_tap' ? message.author : taggedUser;
          const loser = i.customId === 'player1_tap' ? taggedUser : message.author;

          // Send the winner message
          message.channel.send(`Good job, ${winner}! You've won the gun game duel against ${loser}.`);

          // Stop the collector
          tapCollector.stop();
        });

        tapCollector.on('end', () => {
          // If the collector ends without a response, disable the tap buttons
          tapButtonsRow.components.forEach(component => component.setDisabled(true));
          tapMessage.edit({ content: 'The gun game duel has ended without a winner.', components: [tapButtonsRow] });
        });
      } else if (i.customId === 'decline') {
        // Remove the accept/decline buttons
        acceptDeclineRow.components.forEach(component => component.setDisabled(true));
        await duelInviteMessage.edit({ content: `${taggedUser} has declined the gun game duel.`, embeds: [], components: [] });
      }
    });

    acceptDeclineCollector.on('end', () => {
      // If the collector ends without a response, disable the accept/decline buttons
      acceptDeclineRow.components.forEach(component => component.setDisabled(true));
      duelInviteMessage.edit({ content: 'The gun game duel invitation has expired.', embeds: [], components: [] });
    });
  }
});

//rps
client.on('messageCreate', async message => {
    if (!message.content.startsWith('!')) return;
    const args = message.content.slice('!'.length).split(/ +/);
    const command = args.shift().toLowerCase();
    if (command === 'rps') {
        try {
            const choices = [
                {name: 'Πέτρα', emoji: '🪨', beats: 'Ψαλίδι'},
                {name: 'Χαρτί', emoji: '📄', beats: 'Πέτρα'},
                {name: 'Ψαλίδι', emoji: '✂️', beats: 'Χαρτί'}
            ]


             const user = message.mentions.users.first();
              if (!user) return;
              if (user === message.author) return message.reply({content: `**Δεν μπορείς να παίξεις με τον εαυτό σου!**`, ephemeral: true})
              if (user.bot) return message.reply({content: `**Δεν μπορείς να παίξεις με bots!**`, ephemeral: true})

            const embed = new MessageEmbed()
            .setColor('DARK_GREEN')
            .setDescription(`**Είναι η σειρά του ${user}**`)

            const buttons = choices.map((choice) => {
                return new MessageButton()
                .setCustomId(choice.name)
                .setEmoji(choice.emoji)
                .setStyle('SECONDARY')
            })

            const row = new MessageActionRow().addComponents(buttons);

            const reply = await message.reply({content: `**${user}, προκλήθηκες σε 1v1 πέτρα ψαλίδι, χαρτί απο τον/ην ${message.author}**`, embeds: [embed], components: [row]})

            const targetint = await reply.awaitMessageComponent({
                filter: (i) => i.user.id === user.id,
                time: 120000,
            }).catch(async (error) => {
                buttons.forEach((button) => {
                    button.setDisabled(true);
                });
                embed.setDescription(`**Τέλος παιχνιδιού. Ο/Η ${user} δεν απάντησε στην ώρα που έπρεπε**`)
                await reply.edit({embeds: [embed], content: "", components: [row]})
            })

            if (!targetint) return;

            const userChoice = choices.find(
                (choice) => choice.name === targetint.customId,
            )

            await targetint.reply({
                content: `Επέλεξες **${userChoice.name}**`,
                ephemeral: true,
            })

            embed.setDescription(`**Τώρα είναι η σειρά του ${message.author}**`)
            await reply.edit({
                embeds: [embed],
                content: "**STARTED**"
            });

            const initialUserInt = await reply.awaitMessageComponent({
                filter: (i) => i.user.id === message.author.id,
                time: 120000
            }).catch(async (error) => {
                buttons.forEach((button) => {
                    button.setDisabled(true);
                });
                embed.setDescription(`**Τέλος παιχνιδιού. Ο/Η ${message.author} δεν απάντησε στην ώρα που έπρεπε**`)
                await reply.edit({embeds: [embed], content: "", components: [row]})
            })

            if (!initialUserInt) return;

            const intialUserChoice = choices.find(
                (choice) => choice.name === initialUserInt.customId
            );

            await initialUserInt.reply({
                content: `Επέλεξες **${intialUserChoice.name}**`,
                ephemeral: true,
            })

            let result;
            if (userChoice.beats === intialUserChoice.name) {
                result = `**Νικητής: ${user}**`
            }

            if (intialUserChoice.beats === userChoice.name) {
                result = `**Νικητής: ${message.author}**`
            }

            if (userChoice.name === intialUserChoice.name) {
                result = '**Ισοπαλία!**'
            }

            embed.setDescription(
                `Ο/Η ${user} επέλεξε **${userChoice.name}**\nΟ/Η ${message.author} επέλεξε **${intialUserChoice.name}**`
            )
            buttons.forEach((button) => {
                button.setDisabled(true);
            });
            reply.edit({embeds: [embed], content: `${result}`, components: [row]})

        } catch (error) {
            return;
        }
    }
})

client.on('messageCreate', async message => {
    // Έλεγχος εάν το μήνυμα δεν είναι από bot, ξεκινά με το prefix και δεν είναι DM
    if (!message.author.bot && message.content.startsWith('!unban') && message.channel.type !== 'DM') {
        // Έλεγχος εάν ο χρήστης έχει τον ρόλο διαχειριστή
        if (message.member.permissions.has('ADMINISTRATOR')) {
            // Αν έχει τον ρόλο διαχειριστή, μπορεί να εκτελέσει την εντολή unban
            // Εδώ μπορείτε να βάλετε τη λογική για το unban, π.χ.:
            const args = message.content.split(' ');
            if (args.length < 2) {
                return message.reply('**Please provide the ID of the user to unban.**');
            }
            const userID = args[1];
            try {
                await message.guild.members.unban(userID);
                message.reply(`**User with ID ${userID} has been unbanned.**`);
            } catch (error) {
                message.reply('**Could not unban the user. Make sure the ID is valid.**');
            }
        } else {
            // Αν ο χρήστης δεν έχει τον ρόλο διαχειριστή, επιστρέφετε μήνυμα λάθους
            message.reply('**You do not have permission to use this command.**');
        }
    }
});

client.on('messageCreate', async message => {
    // Έλεγχος εάν το μήνυμα δεν είναι από bot και ξεκινάει με το prefix και δεν είναι DM
    if (!message.author.bot && message.content.startsWith('!ban') && message.channel.type !== 'DM') {
        // Έλεγχος εάν ο χρήστης έχει τον ρόλο του διαχειριστή
        if (message.member.permissions.has('ADMINISTRATOR')) {
            // Αν έχει τον ρόλο του διαχειριστή, μπορεί να εκτελέσει την εντολή ban
            // Εδώ μπορείτε να βάλετε τη λογική για το ban, π.χ.:
            const user = message.mentions.members.first();
            if (user) {
                await user.ban();
                message.reply(`${user.user.tag} **has been banned.**`);
            } else {
                message.reply('**Please mention the user to ban.**');
            }
        } else {
            // Αν ο χρήστης δεν έχει τον ρόλο του διαχειριστή, επιστρέφετε μήνυμα λάθους
            message.reply('**You do not have permission to use this command.**');
        }
    }
});

client.on('messageCreate', async message => {
    // Command prefix
    const prefix = '!';

    // Ignore messages from bots or without the prefix
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'kick') {
        // Check if the message member has permission to kick
        if (!message.member.permissions.has('KICK_MEMBERS')) {
            return message.reply('You do not have permission to use this command.');
        }

        // Check if a user was mentioned
        if (!args.length) {
            return message.reply('Please mention a user to kick.');
        }

        // Get the mentioned user
        const member = message.mentions.members.first();
        if (!member) {
            return message.reply('That user is not in this guild.');
        }

        // Check if the member is kickable
        if (!member.kickable) {
            return message.reply('I cannot kick this user. Do they have a higher role? Do I have kick permissions?');
        }

        // Optional: Check if a reason was provided
        const reason = args.slice(1).join(' ') || 'No reason provided';

        // Kick the member
        try {
            await member.kick(reason);
            message.reply(`Successfully kicked ${member.user.tag} for reason: ${reason}`);
        } catch (error) {
            console.error(error);
            message.reply('I was unable to kick the member. An error occurred.');
        }
    }
});

client.on('messageCreate', async message => {
  // Command prefix
  const prefix = '!';

  // Ignore messages from bots or without the prefix
  if (!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'timeout') {
      // Check if the message member has permission to moderate members
      if (!message.member.permissions.has('MODERATE_MEMBERS')) {
          return message.reply('Δεν έχεις πρόσβαση στο command "Timeout".');
      }

      // Check if a user was mentioned
      const member = message.mentions.members.first();
      if (!member) {
          return message.reply('Κάντε Tag το άτομο που θέλετε να κάνετε timeout.');
      }

      // Check if a duration was provided
      const duration = parseInt(args[1]);
      if (isNaN(duration) || duration <= 0) {
          return message.reply('Πες μας τον χρόνο του timeout.');
      }

      // Optional: Check if a reason was provided
      const reason = args.slice(2).join(' ') || 'Δεν έχει δοθεί λογος!';

      // Convert minutes to milliseconds
      const durationMs = duration * 60 * 1000;

      // Timeout the member
      try {
          await member.timeout(durationMs, reason);
          message.reply(`Ο/Η ${member.user.tag} πήρε timeout για ${duration} με λόγο "${reason}"`);

        // Log the timeout action
        const logChannel = client.channels.cache.get(logChannelId);
        if (logChannel) {
            const embed = new MessageEmbed()
                .setTitle('Member Timed Out')
                .setColor('#00FF00')
                .addField('Member', `${member.user.tag} (${member.id})`)
                .addField('Moderator', `${message.author.tag} (${message.author.id})`)
                .addField('Duration', `${duration} minutes`)
                .addField('Reason', reason)
                .setThumbnail(config.logo)
                .setTimestamp();

            logChannel.send({ embeds: [embed] });
        } else {
            console.error('Log channel not found.');

        }
      } catch (error) {
          console.error(error);
          message.reply('Δεν μπόρεσα να κάνω τον ${member.user.tag} Timeout. Προσπάθησε αργότερα!');
              }
          }
      });

////autorole////
client.on('guildMemberAdd', async member => {
    // Fetch the role by ID
    const role = member.guild.roles.cache.get(roleId);

    // Check if the role exists
    if (!role) {
        console.error('Role not found.');
        return;
    }

    // Add the role to the new member
    try {
        await member.roles.add(role);
        console.log(`Assigned role ${role.name} to ${member.user.tag}`);

        // Optional: Log the action in the specified log channel
        const autoroleLog = member.guild.channels.cache.get(autoroleLog);
        if (autoroleLog) {
            autoroleLog.send(`Assigned role ${role.name} to ${member.user.tag} (${member.id})`);
        }
    } catch (error) {
        console.error(`Failed to assign role: ${error}`);
    }
});

client.on('messageCreate', async message => {
    // Ignore messages from bots
    if (message.author.bot) return;

    // Check if the message contains a link
    if (linkRegex.test(message.content)) {
        // Delete the message
        await message.delete();

        // Timeout the user for 1 day (24 hours)
        const member = message.guild.members.cache.get(message.author.id);
        let timeoutSuccess = false;
        let timeoutError = null;

        if (member) {
            const timeoutDuration = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
            try {
                await member.timeout(timeoutDuration, 'Posted a link');
                timeoutSuccess = true;
                console.log(`User ${message.author.tag} has been timed out for posting a link.`);
            } catch (error) {
                timeoutError = error;
                console.error(`Failed to timeout user ${message.author.tag}:`, error);
            }
        } else {
            console.error(`Member ${message.author.tag} not found.`);
        }

        // Create an embed message
        const embed = new MessageEmbed()
            .setTitle('Link Detected and Deleted')
            .setColor('#00FF00')
            .setDescription(`A message containing a link was posted and deleted.`)
            .addField('User', `${message.author.tag} (${message.author.id})`, true)
            .addField('Message Content', message.content, true)
            .addField('Timeout Status', timeoutSuccess ? 'User has been timed out for 24 hours.' : `Failed to timeout user. Error: ${timeoutError}`, true)
            .setTimestamp();

        // Log to the specified channel
        const logChannel = client.channels.cache.get(LinkLog);
        if (logChannel) {
            logChannel.send({ embeds: [embed] });
        } else {
            console.error('Log channel not found. Check the logChannelId.');
        }
    }
});

///////rock gen//////////
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();
  if (command === 'rockstar') {
    return message.reply('**Parta rxidia mou vlk an 8es rock anoi3e ticket na agorasis**')
  }
});

