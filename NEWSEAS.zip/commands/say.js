const { Discord, MessageEmbed } = require('discord.js');
const { config } = require('process');

module.exports = {
  name: 'say',
  description: "This is a say command",
  execute(message, args, Discord) {
    if (message.member.permissions.has("ADMINISTRATOR")) {
      const sayMessage = args.join(" ");
      if (!sayMessage) return;
      message.delete().catch(err => console.log(err));
      let messageArgs = args.join(' ');
      const newEmbed = new MessageEmbed()
        .setColor("#00FF00")
        .setAuthor(`Seaside Project`)
        .setDescription(messageArgs)
.setThumbnail(`https://cdn.discordapp.com/attachments/1243843867439267891/1244203875775545425/Screenshot_2024-05-16_215659.png?ex=665988a8&is=66583728&hm=168a7838126bdcc394ab4c555827b682eb1cb70f6d0800097635583273bcd4fc&`)
      message.channel.send({ embeds: [newEmbed] });
    } else {
      message.delete().catch(err => console.log(err));
    }
  }
}