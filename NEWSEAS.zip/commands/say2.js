module.exports = {
  name: 'say2',
  description: 'Send a message to the current channel',
  execute(message, args) {
    // Check if the user has administrator permissions
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('You do not have the necessary permissions to use this command.')
        .then(msg => {
          // Delete the command message and the bot's reply after 1 second
          setTimeout(() => {
            message.delete().catch(console.error);
            msg.delete().catch(console.error);
          }, 1000);
        })
        .catch(console.error);
    }

    // Get the message to send
    const msg = args.join(' ');
    if (!msg) {
      return message.reply('Please specify a message to send.')
        .then(msg => {
          // Delete the command message and the bot's reply after 1 second
          setTimeout(() => {
            message.delete().catch(console.error);
            msg.delete().catch(console.error);
          }, 1000);
        })
        .catch(console.error);
    }

    // Send the message in the current channel
    message.channel.send(msg)
      .then(() => {
        message.reply('Message sent successfully.')
          .then(msg => {
            // Delete the command message and the bot's reply after 1 second
            setTimeout(() => {
              message.delete().catch(console.error);
              msg.delete().catch(console.error);
            }, 1000);
          })
          .catch(console.error);
      })
      .catch(error => {
        message.reply('An error occurred while sending the message.')
          .then(msg => {
            // Delete the command message and the bot's reply after 1 second
            setTimeout(() => {
              message.delete().catch(console.error);
              msg.delete().catch(console.error);
            }, 1000);
          })
          .catch(console.error);
      });
  },
};
